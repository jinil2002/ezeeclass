# Virtual-Classroom
A web-based virtual classroom designed using Python and it framework Django, Boostrap, JavaScript, HTML5, CSS.
