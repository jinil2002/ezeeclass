from django.apps import AppConfig


class LectureConfig(AppConfig):
    name = 'lecture'
